<body>
 <!-- <?php echo $_POST['id'];?>    -->
<iframe src="doc/<?php echo $_POST['id'];?>" width="500" height="600"></iframe>
tes page
</body>