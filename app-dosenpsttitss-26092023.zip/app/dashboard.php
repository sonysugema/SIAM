<section class="content">
      <div class="container-fluid text-center">
        <div class="card">
          <div class="card-body">
        <!-- Small boxes (Stat box) -->
            <!-- <img src="../logo.png" width="400px;"> -->
            <div class="card">
            <div class="card-header">
                <h2 >Visi & Misi <br> STTI Sony Sugema</h2>
              </div>
              <div class="card-header">
                <h2 class="text-left">Visi</h2>
              </div> 
              <div class="card-header text-left">
                 <li>masa depan Sekolah Tinggi Teknologi Informatika Sony Sugema (STTIS) : Menjadikan STTIS sebagai sentral perguruan tinggi informatika di Indonesia yang mempunyai keunggulan bersaing secara global.</li> 
              </div> 
            </div>  

            <div class="card">
              <div class="card-header">
                <h2 class="text-left">Misi</h2>
              </div> 
              <div class="card-header text-left">
                 <li>Mendidik mahasiswa menjadi sarjana atau ahli madya yang bertaqwa kepada Tuhan Yang Maha Esa, berkepribadian, mempunyai keahlian di bidang teknologi informasi, mampu memenangkan persaingan, dan mempunyai jiwa entrepreneurship.
                 </li> 
                 <!-- <li>Melaksanakan Penelitian yang Relevan di Bidang Informatika guna Menghasilkan Lulusan yang
                  profesional
                 </li>
                 <li>Melaksanakan Pengabdian Kepada Masyarakat yang Bermanfaat, Meningkatan Kesejahteraan
                  Bagi Masyarakat, dan Menghasilkan Lulusan Profesional
                 </li>
                 <li>Menjalin Kemitraan, Kerjasama dengan Dunia Usaha dan Industri guna Menghasilkan Lulusan yang Profesional
                 </li> -->
              </div> 
            </div> 
          </div>
        </div>    
      </div><!-- /.container-fluid -->
    </section>